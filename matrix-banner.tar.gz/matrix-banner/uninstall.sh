#!/bin/bash
# =============================================================================
# uninstall.sh — Remove Matrix Login Banner from Debian
# Run as root: sudo bash uninstall.sh
# =============================================================================

set -euo pipefail

G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; C='\033[1;36m'; N='\033[0m'
info()    { printf "${G}[✔]${N} %s\n" "$*"; }
warn()    { printf "${Y}[!]${N} %s\n" "$*"; }
heading() { printf "\n${C}══[ %s ]══${N}\n" "$*"; }

[ "$(id -u)" -eq 0 ] || { printf "${R}[✘]${N} Must be run as root.\n"; exit 1; }

heading "Matrix Banner — Uninstaller"

# Remove profile.d banner
if [ -f /etc/profile.d/00-matrix-banner.sh ]; then
    rm -f /etc/profile.d/00-matrix-banner.sh
    info "Removed /etc/profile.d/00-matrix-banner.sh"
fi

# Remove MOTD fragment
if [ -f /etc/update-motd.d/10-matrix-motd ]; then
    rm -f /etc/update-motd.d/10-matrix-motd
    info "Removed /etc/update-motd.d/10-matrix-motd"
fi

# Re-enable default Debian MOTD scripts if they exist but lost exec bit
for default_motd in \
    /etc/update-motd.d/10-uname \
    /etc/update-motd.d/00-header; do
    if [ -f "$default_motd" ] && [ ! -x "$default_motd" ]; then
        chmod +x "$default_motd"
        info "Re-enabled: $default_motd"
    fi
done

# Remove SSH banner file and directive
if [ -f /etc/ssh/banner.txt ]; then
    rm -f /etc/ssh/banner.txt
    info "Removed /etc/ssh/banner.txt"
fi

if grep -qE '^\s*Banner\s+/etc/ssh/banner.txt' /etc/ssh/sshd_config 2>/dev/null; then
    sed -i -E '/^\s*Banner\s+\/etc\/ssh\/banner.txt/d' /etc/ssh/sshd_config
    sed -i '/^# Matrix login banner/d' /etc/ssh/sshd_config
    if sshd -t 2>/dev/null; then
        systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || \
            warn "Reload SSH manually: systemctl reload ssh"
        info "SSH banner directive removed and daemon reloaded"
    fi
fi

heading "Uninstall complete"
warn "Backup files (.bak.*) were left in place — remove manually if needed"
printf '\n'
