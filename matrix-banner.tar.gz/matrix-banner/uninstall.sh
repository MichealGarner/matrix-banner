#!/bin/bash
# =============================================================================
# uninstall.sh — Remove Matrix Login Banner from Debian
# Run as root: sudo bash uninstall.sh
# =============================================================================

set -euo pipefail

G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; C='\033[1;36m'; N='\033[0m'
info()    { printf "${G}[✔]${N} %s\n" "$*"; }
warn()    { printf "${Y}[!]${N} %s\n" "$*"; }
heading() { printf "\n${C}══[ %s ]══${N}\n" "$*"; }

[ "$(id -u)" -eq 0 ] || { printf "${R}[✘]${N} Must be run as root.\n"; exit 1; }

heading "Matrix Banner — Uninstaller"

# Remove profile.d banner
if [ -f /etc/profile.d/00-matrix-banner.sh ]; then
    rm -f /etc/profile.d/00-matrix-banner.sh
    info "Removed /etc/profile.d/00-matrix-banner.sh"
fi

# Remove MOTD fragment
if [ -f /etc/update-motd.d/10-matrix-motd ]; then
    rm -f /etc/update-motd.d/10-matrix-motd
    info "Removed /etc/update-motd.d/10-matrix-motd"
fi

# Stop any stale executable copies of the MOTD fragment (left by older installers)
# from running — run-parts executes every executable file in this directory.
for stale in /etc/update-motd.d/10-matrix-motd.*; do
    [ -e "$stale" ] || continue
    chmod a-x "$stale"
    warn "Disabled stale backup copy: $stale (delete it when you no longer need it)"
done

# Remove the update-count cache helper, its apt hook and the cache file
for f in /usr/local/sbin/matrix-update-cache \
         /etc/apt/apt.conf.d/99matrix-banner \
         /var/cache/matrix-banner-updates; do
    if [ -f "$f" ]; then
        rm -f "$f"
        info "Removed $f"
    fi
done

# Re-enable default Debian MOTD scripts if they exist but lost exec bit
for default_motd in \
    /etc/update-motd.d/10-uname \
    /etc/update-motd.d/00-header; do
    if [ -f "$default_motd" ] && [ ! -x "$default_motd" ]; then
        chmod +x "$default_motd"
        info "Re-enabled: $default_motd"
    fi
done

# Remove SSH banner file and directive
if [ -f /etc/ssh/banner.txt ]; then
    rm -f /etc/ssh/banner.txt
    info "Removed /etc/ssh/banner.txt"
fi

if grep -qE '^\s*Banner\s+/etc/ssh/banner.txt' /etc/ssh/sshd_config 2>/dev/null; then
    sed -i -E '/^\s*Banner\s+\/etc\/ssh\/banner.txt/d' /etc/ssh/sshd_config
    sed -i '/^# Matrix login banner/d' /etc/ssh/sshd_config
    if sshd -t 2>/dev/null; then
        systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || \
            warn "Reload SSH manually: systemctl reload ssh"
        info "SSH banner directive removed and daemon reloaded"
    fi
fi

heading "Uninstall complete"
warn "Backups in /var/backups/matrix-banner (and any older .bak.* files) were left in place — remove manually if needed"
printf '\n'
