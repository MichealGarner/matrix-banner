#!/bin/bash
# =============================================================================
# /etc/profile.d/00-matrix-banner.sh
# Matrix-themed animated login banner
# Runs for all interactive login shells on Debian systems
# =============================================================================

# Only run in interactive shells with a terminal
[ -t 1 ] || return
[[ $- == *i* ]] || return

# ─── ANSI colour palette ─────────────────────────────────────────────────────
RESET='\033[0m'
BOLD='\033[1m'
DIM='\033[2m'

# Greens (Matrix palette)
GREEN_BRIGHT='\033[1;32m'
GREEN='\033[0;32m'
GREEN_DIM='\033[2;32m'

# Accents
WHITE='\033[1;37m'
RED_BOLD='\033[1;31m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
CYAN_BOLD='\033[1;36m'

# ─── Typewriter effect ────────────────────────────────────────────────────────
typewrite() {
    local text="$1"
    local delay="${2:-0.04}"
    local colour="${3:-}"
    for ((i = 0; i < ${#text}; i++)); do
        printf "${colour}%s${RESET}" "${text:$i:1}"
        sleep "$delay"
    done
    printf '\n'
}

# ─── Pause with optional dot animation ───────────────────────────────────────
dot_pause() {
    local dots="${1:-3}"
    local delay="${2:-0.4}"
    for ((i = 0; i < dots; i++)); do
        printf "${GREEN_DIM}.${RESET}"
        sleep "$delay"
    done
    printf '\n'
}

# ─── Random Matrix messages ───────────────────────────────────────────────────
MATRIX_MESSAGES=(
    "wake up, %s..."
    "the Matrix has you, %s..."
    "follow the white rabbit, %s."
    "knock, knock, %s."
    "they're watching, %s."
    "there is no spoon, %s."
    "free your mind, %s."
    "the truth awaits you, %s."
    "how deep does the rabbit hole go, %s?"
    "choice is an illusion, %s."
)

RANDOM_MESSAGE="${MATRIX_MESSAGES[$(( RANDOM % ${#MATRIX_MESSAGES[@]} ))]}"
# shellcheck disable=SC2059
PERSONALISED="$(printf "$RANDOM_MESSAGE" "$USER")"

# ─── System information ───────────────────────────────────────────────────────
HOSTNAME_SHORT="$(hostname -s)"
KERNEL="$(uname -r)"
UPTIME_STR="$(uptime -p 2>/dev/null | sed 's/^up //' || echo 'unknown')"
IP_ADDR="$(hostname -I 2>/dev/null | awk '{print $1}' || echo 'unknown')"
CPU_LOAD="$(cut -d' ' -f1 /proc/loadavg 2>/dev/null || echo '?')"
MEM_TOTAL="$(awk '/MemTotal/ {printf "%.0f", $2/1024}' /proc/meminfo 2>/dev/null || echo '?')"
MEM_AVAIL="$(awk '/MemAvailable/ {printf "%.0f", $2/1024}' /proc/meminfo 2>/dev/null || echo '?')"
MEM_USED=$(( MEM_TOTAL - MEM_AVAIL ))
DISK_USED="$(df -h / 2>/dev/null | awk 'NR==2{print $3"/"$2" ("$5" used)"}'  || echo '?')"
TIMESTAMP="$(date '+%Y-%m-%d %H:%M:%S %Z')"
DEBIAN_VER="$(cat /etc/debian_version 2>/dev/null || echo 'unknown')"

# ─── BEGIN BANNER ─────────────────────────────────────────────────────────────

clear

# Opening teletype flicker line
printf "${GREEN_DIM}"
printf 'Call trans opt: received. '
printf "$(date '+%m-%d-%y %H:%M:%S') REC:Loc\n"
sleep 0.3
printf '     Trace program: running'
sleep 0.2
dot_pause 3 0.3
printf "${RESET}"
sleep 0.2

# Personalised Matrix greeting (typewriter)
printf '\n'
typewrite "           ${PERSONALISED}" 0.05 "${GREEN}"
sleep 0.5

# ASCII art - the iconic figure (green, centre-ish)
printf "${GREEN_DIM}"
cat << 'ASCIIART'

                        (`.         ,-,
                        ` `.    ,;' /
                         `.  ,'/ .'
                          `. X /.'
                .-;--''--.._` ` (
              .'            /   `
             ,           ` '   Q '
             ,         ,   `._    \
          ,.|         '     `-.;_'
          :  . `  ;    `  ` --,.._;
           ' `    ,   )   .'
              `._ ,  '   /_
                 ; ,''-,;' ``-
                  ``-..__``--`
ASCIIART
printf "${RESET}"
sleep 0.3

# ─── Hostname banner via figlet-style manual ASCII (or figlet if installed) ───
printf '\n'
if command -v figlet &>/dev/null; then
    figlet -f slant "$HOSTNAME_SHORT" | while IFS= read -r line; do
        printf "${GREEN_BRIGHT}%s${RESET}\n" "$line"
    done
else
    # Fallback: plain coloured hostname
    printf "${GREEN_BRIGHT}  [ %s ]${RESET}\n" "$HOSTNAME_SHORT"
fi

printf '\n'

# ─── Legal / warning block ────────────────────────────────────────────────────
printf "${RED_BOLD}"
printf '  ╔══════════════════════════════════════════════════════════════╗\n'
printf '  ║               !! AUTHORISED ACCESS ONLY !!                  ║\n'
printf '  ╠══════════════════════════════════════════════════════════════╣\n'
printf "${RESET}${YELLOW}"
printf '  ║  This system is privately owned and monitored continuously.  ║\n'
printf '  ║  All connections, commands, and file activity are logged.    ║\n'
printf '  ║  Unauthorised access or misuse will be investigated and      ║\n'
printf '  ║  prosecuted under the Computer Misuse Act 1990 (UK) and     ║\n'
printf '  ║  applicable international law.                               ║\n'
printf "${RESET}${RED_BOLD}"
printf '  ║                                                              ║\n'
printf '  ║       I check logs.  I hold a grudge.  You have been        ║\n'
printf '  ║                    w a r n e d .                            ║\n'
printf '  ╚══════════════════════════════════════════════════════════════╝\n'
printf "${RESET}"

printf '\n'

# ─── System status panel ─────────────────────────────────────────────────────
printf "${GREEN_DIM}  ┌─[ ${RESET}${CYAN_BOLD}SYSTEM STATUS${RESET}${GREEN_DIM} ]──────────────────────────────────────────┐${RESET}\n"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Host:"       "$HOSTNAME_SHORT (Debian $DEBIAN_VER)"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Kernel:"     "$KERNEL"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "IP Address:" "$IP_ADDR"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Uptime:"     "$UPTIME_STR"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Load (1m):"  "$CPU_LOAD"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Memory:"     "${MEM_USED}MB used / ${MEM_TOTAL}MB total"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Disk (/):"   "$DISK_USED"
printf "${GREEN_DIM}  │${RESET}  %-18s ${GREEN}%-40s${RESET}${GREEN_DIM}│${RESET}\n" "Login time:" "$TIMESTAMP"
printf "${GREEN_DIM}  └────────────────────────────────────────────────────────────┘${RESET}\n"

printf '\n'

# ─── Closing typewriter line ──────────────────────────────────────────────────
typewrite "  There is no place like 127.0.0.1." 0.03 "${GREEN_DIM}"
printf '\n'
