# Matrix Login Banner — Debian

A Matrix-themed, animated, colourised login experience for Debian Linux systems.
Combines a pre-auth SSH warning, a dynamic MOTD with live system stats, and an
animated typewriter-style shell banner with random personalised greetings.

---

## What Gets Installed

```
/etc/profile.d/00-matrix-banner.sh   ← Animated banner (runs on interactive login)
/etc/update-motd.d/10-matrix-motd    ← Dynamic MOTD (system stats, built by PAM)
/etc/ssh/banner.txt                  ← Pre-auth legal warning (plain text)
/etc/ssh/sshd_config                 ← Banner directive added/updated
```

---

## Quick Start

```bash
sudo bash install.sh
```

Test immediately (without logging out):

```bash
bash /etc/profile.d/00-matrix-banner.sh
```

---

## How It Works

### Layer 1 — SSH Pre-auth Banner (`/etc/ssh/banner.txt`)
Shown to *everyone* who connects via SSH **before** they authenticate — including
unauthorised parties. Plain text only (no ANSI), as this is displayed by the SSH
client and colour support is not guaranteed. Contains the legal warning notice.

This is controlled by the `Banner` directive in `/etc/ssh/sshd_config`.

### Layer 2 — Dynamic MOTD (`/etc/update-motd.d/10-matrix-motd`)
On Debian, PAM assembles the MOTD at login time by running all executable scripts
in `/etc/update-motd.d/` and concatenating their stdout. This script outputs:

- Hostname (via figlet if installed, plain fallback otherwise)
- Legal warning box (colourised)
- Live system stats: kernel, IP, uptime, load, memory, disk, date/time
- Pending update count (read from a cache refreshed by an apt hook — nothing slow runs at login)
- Failed login warning (if `lastb` is available and there were failures)

### Layer 3 — Animated Shell Banner (`/etc/profile.d/00-matrix-banner.sh`)
Runs for all users in interactive login shells (bash, zsh, etc. — anything that
sources `/etc/profile`). Produces:

- Teletype-style opening line with timestamp
- Random personalised Matrix greeting (typewriter animation)
- The iconic ASCII figure from Metasploit/Matrix culture
- Figlet hostname (or fallback)
- Warning box
- Live system stats panel
- Closing one-liner

The animated layer is deliberately shown *after* the MOTD. SSH sessions will
see both; `su -` sessions see only the profile.d banner.

---

## Customisation

### Change the greeting messages
Edit the `MATRIX_MESSAGES` array in `00-matrix-banner.sh`. Each message can
contain `%s` which is replaced with `$USER` at runtime:

```bash
MATRIX_MESSAGES=(
    "wake up, %s..."
    "your own message here, %s."
    "another line, %s."
)
```

### Change the hostname font
Install any figlet font pack:

```bash
apt install figlet
# Extra fonts:
apt install figlet-fonts figlet-fonts-extra   # if available
# Or download from: http://www.figlet.org/fontdb.cgi
# Place .flf files in /usr/share/figlet/
```

Then change the `-f slant` argument in both scripts:

```bash
figlet -f big "$HOSTNAME_SHORT"    # larger
figlet -f small "$HOSTNAME_SHORT"  # compact
figlet -f banner "$HOSTNAME_SHORT" # classic
```

### Adjust typewriter speed
Change the `delay` argument in `typewrite` calls. Default is `0.04` seconds per
character. Set to `0` to disable animation:

```bash
typewrite "your text here" 0.02   # faster
typewrite "your text here" 0.08   # slower (dramatic)
typewrite "your text here" 0      # instant
```

### Change the legal jurisdiction
The warning references the Computer Misuse Act 1990 (UK). Edit both
`00-matrix-banner.sh` and `10-matrix-motd` to update for your jurisdiction.

### Disable the animated banner for specific users
Add this near the top of the user's `~/.bashrc` or `~/.bash_profile`:

```bash
# Skip the matrix banner for this user
MATRIX_BANNER_SKIP=1
```

Then add to `00-matrix-banner.sh`, just after the `[ -t 1 ]` check:

```bash
[ "${MATRIX_BANNER_SKIP:-0}" = "1" ] && return
```

---

## Deploying to Multiple Machines

### Option A — rsync
```bash
rsync -av matrix-banner/ root@192.168.1.x:/tmp/matrix-banner/
ssh root@192.168.1.x "bash /tmp/matrix-banner/install.sh"
```

### Option B — Loop over a host list
```bash
HOSTS="server1 server2 server3"
for HOST in $HOSTS; do
    echo "=== Deploying to $HOST ==="
    rsync -av matrix-banner/ root@${HOST}:/tmp/matrix-banner/
    ssh root@${HOST} "bash /tmp/matrix-banner/install.sh"
done
```

### Option C — Ansible
```yaml
- name: Deploy Matrix Banner
  hosts: all
  tasks:
    - name: Copy banner files
      copy:
        src: matrix-banner/
        dest: /tmp/matrix-banner/
        mode: preserve

    - name: Run installer
      command: bash /tmp/matrix-banner/install.sh
      args:
        creates: /etc/profile.d/00-matrix-banner.sh
```

---

## Requirements

| Package  | Required | Purpose                    | Install                  |
|----------|----------|----------------------------|--------------------------|
| bash     | Yes      | Script runtime             | Pre-installed on Debian  |
| figlet   | No       | Hostname ASCII art         | `apt install figlet`     |
| lastb    | No       | Failed login count         | Part of `util-linux`     |
| sshd     | No       | Pre-auth banner            | `apt install openssh-server` |

The scripts degrade gracefully if figlet or lastb are absent.

---

## Uninstall

```bash
sudo bash uninstall.sh
```

Backup files (`.bak.YYYYMMDDHHMMSS`, kept in `/var/backups/matrix-banner/`) are left in place and must be removed
manually if no longer needed.

---

## File Layout

```
matrix-banner/
├── install.sh                          ← Run this as root
├── uninstall.sh
├── README.md                           ← This file
├── usr/
│   └── local/
│       └── sbin/
│           └── matrix-update-cache       ← Refreshes the pending-update count (run by apt hook)
└── etc/
    ├── apt/
    │   └── apt.conf.d/
    │       └── 99matrix-banner           ← apt hook that runs the cache refresher
    ├── profile.d/
    │   └── 00-matrix-banner.sh         ← Animated login banner
    ├── update-motd.d/
    │   └── 10-matrix-motd              ← Dynamic MOTD fragment
    └── ssh/
        └── banner.txt                  ← Pre-auth SSH warning
```
