#!/bin/bash
# =============================================================================
# install.sh — Matrix Login Banner Installer for Debian
# Run as root: sudo bash install.sh
# =============================================================================

set -euo pipefail

# ─── Colours for installer output ────────────────────────────────────────────
G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; C='\033[1;36m'; N='\033[0m'

info()    { printf "${G}[✔]${N} %s\n" "$*"; }
warn()    { printf "${Y}[!]${N} %s\n" "$*"; }
error()   { printf "${R}[✘]${N} %s\n" "$*"; exit 1; }
heading() { printf "\n${C}══[ %s ]══${N}\n" "$*"; }

# ─── Root check ───────────────────────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
    error "This script must be run as root. Try: sudo bash install.sh"
fi

# ─── Debian check ─────────────────────────────────────────────────────────────
if [ ! -f /etc/debian_version ]; then
    warn "This system does not appear to be Debian-based. Proceed anyway? [y/N]"
    read -r answer
    [[ "$answer" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 0; }
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

heading "Matrix Login Banner — Installer"
printf "  Installing on: %s (%s)\n" "$(hostname -s)" "$(cat /etc/debian_version 2>/dev/null || echo unknown)"
printf "  Source dir:    %s\n\n" "$SCRIPT_DIR"

# ─── Optional: Install figlet ─────────────────────────────────────────────────
heading "Checking dependencies"
if command -v figlet &>/dev/null; then
    info "figlet already installed"
else
    warn "figlet not found — install it for the best hostname banner? [Y/n]"
    read -r answer
    if [[ ! "$answer" =~ ^[Nn]$ ]]; then
        apt-get update -qq && apt-get install -y figlet
        info "figlet installed"
    else
        warn "Skipping figlet — a plain hostname fallback will be used"
    fi
fi

# ─── 1. profile.d animated banner ────────────────────────────────────────────
heading "Installing animated profile banner"

PROFILE_SRC="$SCRIPT_DIR/etc/profile.d/00-matrix-banner.sh"
PROFILE_DEST="/etc/profile.d/00-matrix-banner.sh"

if [ ! -f "$PROFILE_SRC" ]; then
    error "Missing source file: $PROFILE_SRC"
fi

# Backup existing if present
if [ -f "$PROFILE_DEST" ]; then
    cp "$PROFILE_DEST" "${PROFILE_DEST}.bak.$(date +%Y%m%d%H%M%S)"
    warn "Backed up existing profile banner"
fi

cp "$PROFILE_SRC" "$PROFILE_DEST"
chmod 644 "$PROFILE_DEST"
info "Installed: $PROFILE_DEST"

# ─── 2. Dynamic MOTD fragment ─────────────────────────────────────────────────
heading "Installing dynamic MOTD"

MOTD_DIR="/etc/update-motd.d"
MOTD_SRC="$SCRIPT_DIR/etc/update-motd.d/10-matrix-motd"
MOTD_DEST="$MOTD_DIR/10-matrix-motd"

if [ ! -d "$MOTD_DIR" ]; then
    error "$MOTD_DIR does not exist — is this a Debian/Ubuntu system with PAM MOTD support?"
fi

# Disable Debian's default uname MOTD if present (we cover it ourselves)
for default_motd in \
    "$MOTD_DIR/10-uname" \
    "$MOTD_DIR/00-header" \
    "$MOTD_DIR/50-motd-news"; do
    if [ -x "$default_motd" ]; then
        chmod -x "$default_motd"
        warn "Disabled default MOTD script: $(basename "$default_motd")"
    fi
done

if [ -f "$MOTD_DEST" ]; then
    cp "$MOTD_DEST" "${MOTD_DEST}.bak.$(date +%Y%m%d%H%M%S)"
    warn "Backed up existing MOTD fragment"
fi

cp "$MOTD_SRC" "$MOTD_DEST"
chmod 755 "$MOTD_DEST"       # Must be executable for PAM to run it
info "Installed: $MOTD_DEST"

# ─── 3. SSH pre-auth banner ───────────────────────────────────────────────────
heading "Configuring SSH pre-authentication banner"

BANNER_SRC="$SCRIPT_DIR/etc/ssh/banner.txt"
BANNER_DEST="/etc/ssh/banner.txt"
SSHD_CONFIG="/etc/ssh/sshd_config"

if [ ! -f "$BANNER_SRC" ]; then
    error "Missing source file: $BANNER_SRC"
fi

cp "$BANNER_SRC" "$BANNER_DEST"
chmod 644 "$BANNER_DEST"
info "Installed banner text: $BANNER_DEST"

# Add or update Banner directive in sshd_config
if [ -f "$SSHD_CONFIG" ]; then
    if grep -qE '^\s*#?\s*Banner\s' "$SSHD_CONFIG"; then
        # Replace existing (commented or active) Banner line
        sed -i -E 's|^\s*#?\s*Banner\s.*|Banner /etc/ssh/banner.txt|' "$SSHD_CONFIG"
        info "Updated Banner directive in $SSHD_CONFIG"
    else
        # Append to file
        echo '' >> "$SSHD_CONFIG"
        echo '# Matrix login banner' >> "$SSHD_CONFIG"
        echo 'Banner /etc/ssh/banner.txt' >> "$SSHD_CONFIG"
        info "Added Banner directive to $SSHD_CONFIG"
    fi

    # Validate sshd config before reloading
    if sshd -t 2>/dev/null; then
        info "sshd config validated — reloading SSH daemon"
        systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || \
            warn "Could not reload SSH — please run: systemctl reload ssh"
    else
        error "sshd config validation FAILED — please check $SSHD_CONFIG manually"
    fi
else
    warn "Could not find $SSHD_CONFIG — SSH banner not configured"
fi

# ─── 4. Disable/clear static /etc/motd ───────────────────────────────────────
heading "Clearing static /etc/motd"

if [ -s /etc/motd ]; then
    cp /etc/motd "/etc/motd.bak.$(date +%Y%m%d%H%M%S)"
    warn "Backed up existing /etc/motd"
fi

# On Debian with PAM update-motd, /etc/motd is auto-managed.
# Truncate so we don't get double output.
> /etc/motd
info "Cleared /etc/motd (dynamic MOTD will be used instead)"

# ─── Done ─────────────────────────────────────────────────────────────────────
heading "Installation complete"
printf '\n'
printf "  The following were installed/configured:\n"
printf "  ${G}✔${N}  /etc/profile.d/00-matrix-banner.sh  (animated shell banner)\n"
printf "  ${G}✔${N}  /etc/update-motd.d/10-matrix-motd   (dynamic MOTD with system stats)\n"
printf "  ${G}✔${N}  /etc/ssh/banner.txt                 (pre-auth SSH warning)\n"
printf "  ${G}✔${N}  /etc/ssh/sshd_config                (Banner directive set)\n"
printf '\n'
printf "  To test the animated banner right now:\n"
printf "    ${C}bash /etc/profile.d/00-matrix-banner.sh${N}\n"
printf '\n'
printf "  To uninstall:\n"
printf "    ${C}bash uninstall.sh${N}\n"
printf '\n'
