#!/bin/bash
# =============================================================================
# install.sh — Matrix Login Banner Installer for Debian
# Run as root: sudo bash install.sh
# =============================================================================

set -euo pipefail

# ─── Colours for installer output ────────────────────────────────────────────
G='\033[1;32m'; Y='\033[1;33m'; R='\033[1;31m'; C='\033[1;36m'; N='\033[0m'

info()    { printf "${G}[✔]${N} %s\n" "$*"; }
warn()    { printf "${Y}[!]${N} %s\n" "$*"; }
error()   { printf "${R}[✘]${N} %s\n" "$*"; exit 1; }
heading() { printf "\n${C}══[ %s ]══${N}\n" "$*"; }

# ─── Root check ───────────────────────────────────────────────────────────────
if [ "$(id -u)" -ne 0 ]; then
    error "This script must be run as root. Try: sudo bash install.sh"
fi

# ─── Debian check ─────────────────────────────────────────────────────────────
if [ ! -f /etc/debian_version ]; then
    warn "This system does not appear to be Debian-based. Proceed anyway? [y/N]"
    read -r answer
    [[ "$answer" =~ ^[Yy]$ ]] || { echo "Aborted."; exit 0; }
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ─── Backups ──────────────────────────────────────────────────────────────────
# Backups are kept OUT of /etc/update-motd.d and /etc/profile.d. run-parts executes
# every executable file in update-motd.d, so a ".bak" copy left next to the real
# script would keep running the old version at every login.
BACKUP_DIR="/var/backups/matrix-banner"
mkdir -p "$BACKUP_DIR"

backup_file() {
    local src="$1"
    local dest
    dest="$BACKUP_DIR/$(basename "$src").bak.$(date +%Y%m%d%H%M%S)"
    cp -p "$src" "$dest"
    chmod a-x "$dest"
}

heading "Matrix Login Banner — Installer"
printf "  Installing on: %s (%s)\n" "$(hostname -s)" "$(cat /etc/debian_version 2>/dev/null || echo unknown)"
printf "  Source dir:    %s\n\n" "$SCRIPT_DIR"

# ─── Optional: Install figlet ─────────────────────────────────────────────────
heading "Checking dependencies"
if command -v figlet &>/dev/null; then
    info "figlet already installed"
else
    warn "figlet not found — install it for the best hostname banner? [Y/n]"
    read -r answer
    if [[ ! "$answer" =~ ^[Nn]$ ]]; then
        apt-get update -qq && apt-get install -y figlet
        info "figlet installed"
    else
        warn "Skipping figlet — a plain hostname fallback will be used"
    fi
fi

# ─── 1. profile.d animated banner ────────────────────────────────────────────
heading "Installing animated profile banner"

PROFILE_SRC="$SCRIPT_DIR/etc/profile.d/00-matrix-banner.sh"
PROFILE_DEST="/etc/profile.d/00-matrix-banner.sh"

if [ ! -f "$PROFILE_SRC" ]; then
    error "Missing source file: $PROFILE_SRC"
fi

# Backup existing if present
if [ -f "$PROFILE_DEST" ]; then
    backup_file "$PROFILE_DEST"
    warn "Backed up existing profile banner to $BACKUP_DIR"
fi

cp "$PROFILE_SRC" "$PROFILE_DEST"
chmod 644 "$PROFILE_DEST"
info "Installed: $PROFILE_DEST"

# ─── 2. Dynamic MOTD fragment ─────────────────────────────────────────────────
heading "Installing dynamic MOTD"

MOTD_DIR="/etc/update-motd.d"
MOTD_SRC="$SCRIPT_DIR/etc/update-motd.d/10-matrix-motd"
MOTD_DEST="$MOTD_DIR/10-matrix-motd"

if [ ! -d "$MOTD_DIR" ]; then
    error "$MOTD_DIR does not exist — is this a Debian/Ubuntu system with PAM MOTD support?"
fi

# Disable Debian's default uname MOTD if present (we cover it ourselves)
for default_motd in \
    "$MOTD_DIR/10-uname" \
    "$MOTD_DIR/00-header" \
    "$MOTD_DIR/50-motd-news"; do
    if [ -x "$default_motd" ]; then
        chmod -x "$default_motd"
        warn "Disabled default MOTD script: $(basename "$default_motd")"
    fi
done

# Older versions of this installer left executable "10-matrix-motd.bak.*" copies
# in this directory. run-parts executes them, re-running the old (slow) script at
# every login. Move any such leftovers out.
for stale in "$MOTD_DIR"/10-matrix-motd.*; do
    [ -e "$stale" ] || continue
    mv -f "$stale" "$BACKUP_DIR/$(basename "$stale")"
    chmod a-x "$BACKUP_DIR/$(basename "$stale")"
    warn "Moved stale backup out of $MOTD_DIR: $(basename "$stale")"
done

if [ -f "$MOTD_DEST" ]; then
    backup_file "$MOTD_DEST"
    warn "Backed up existing MOTD fragment to $BACKUP_DIR"
fi

cp "$MOTD_SRC" "$MOTD_DEST"
chmod 755 "$MOTD_DEST"       # Must be executable for PAM to run it
info "Installed: $MOTD_DEST"

# ─── 2b. Pending-update cache (keeps login fast) ──────────────────────────────
heading "Installing update-count cache"

CACHE_BIN_SRC="$SCRIPT_DIR/usr/local/sbin/matrix-update-cache"
CACHE_BIN_DEST="/usr/local/sbin/matrix-update-cache"
CACHE_HOOK_SRC="$SCRIPT_DIR/etc/apt/apt.conf.d/99matrix-banner"
CACHE_HOOK_DEST="/etc/apt/apt.conf.d/99matrix-banner"

for f in "$CACHE_BIN_SRC" "$CACHE_HOOK_SRC"; do
    [ -f "$f" ] || error "Missing source file: $f"
done

if [ -d /etc/apt/apt.conf.d ] && command -v apt-get &>/dev/null; then
    install -d /usr/local/sbin
    install -m 755 "$CACHE_BIN_SRC" "$CACHE_BIN_DEST"
    install -m 644 "$CACHE_HOOK_SRC" "$CACHE_HOOK_DEST"
    info "Installed: $CACHE_BIN_DEST"
    info "Installed: $CACHE_HOOK_DEST"
    # Prime the cache now (can take a few seconds on small devices)
    if "$CACHE_BIN_DEST"; then
        info "Update-count cache primed"
    else
        warn "Could not prime the update cache — it will refresh on the next apt run"
    fi
else
    warn "apt not found — pending-update count will show 0"
fi

# ─── 3. SSH pre-auth banner ───────────────────────────────────────────────────
heading "Configuring SSH pre-authentication banner"

BANNER_SRC="$SCRIPT_DIR/etc/ssh/banner.txt"
BANNER_DEST="/etc/ssh/banner.txt"
SSHD_CONFIG="/etc/ssh/sshd_config"

if [ ! -f "$BANNER_SRC" ]; then
    error "Missing source file: $BANNER_SRC"
fi

cp "$BANNER_SRC" "$BANNER_DEST"
chmod 644 "$BANNER_DEST"
info "Installed banner text: $BANNER_DEST"

# Add or update Banner directive in sshd_config
if [ -f "$SSHD_CONFIG" ]; then
    if grep -qE '^\s*#?\s*Banner\s' "$SSHD_CONFIG"; then
        # Replace existing (commented or active) Banner line
        sed -i -E 's|^\s*#?\s*Banner\s.*|Banner /etc/ssh/banner.txt|' "$SSHD_CONFIG"
        info "Updated Banner directive in $SSHD_CONFIG"
    else
        # Append to file
        echo '' >> "$SSHD_CONFIG"
        echo '# Matrix login banner' >> "$SSHD_CONFIG"
        echo 'Banner /etc/ssh/banner.txt' >> "$SSHD_CONFIG"
        info "Added Banner directive to $SSHD_CONFIG"
    fi

    # Validate sshd config before reloading
    if sshd -t 2>/dev/null; then
        info "sshd config validated — reloading SSH daemon"
        systemctl reload ssh 2>/dev/null || systemctl reload sshd 2>/dev/null || \
            warn "Could not reload SSH — please run: systemctl reload ssh"
    else
        error "sshd config validation FAILED — please check $SSHD_CONFIG manually"
    fi
else
    warn "Could not find $SSHD_CONFIG — SSH banner not configured"
fi

# ─── 4. Disable/clear static /etc/motd ───────────────────────────────────────
heading "Clearing static /etc/motd"

if [ -s /etc/motd ]; then
    backup_file /etc/motd
    warn "Backed up existing /etc/motd to $BACKUP_DIR"
fi

# On Debian with PAM update-motd, /etc/motd is auto-managed.
# Truncate so we don't get double output.
> /etc/motd
info "Cleared /etc/motd (dynamic MOTD will be used instead)"

# ─── Done ─────────────────────────────────────────────────────────────────────
heading "Installation complete"
printf '\n'
printf "  The following were installed/configured:\n"
printf "  ${G}✔${N}  /etc/profile.d/00-matrix-banner.sh  (animated shell banner)\n"
printf "  ${G}✔${N}  /etc/update-motd.d/10-matrix-motd   (dynamic MOTD with system stats)\n"
printf "  ${G}✔${N}  /usr/local/sbin/matrix-update-cache (refreshes cached update count)\n"
printf "  ${G}✔${N}  /etc/apt/apt.conf.d/99matrix-banner (apt hook for the cache)\n"
printf "  ${G}✔${N}  /etc/ssh/banner.txt                 (pre-auth SSH warning)\n"
printf "  ${G}✔${N}  /etc/ssh/sshd_config                (Banner directive set)\n"
printf '\n'
printf "  Backups of any replaced files are in: ${C}%s${N}\n\n" "$BACKUP_DIR"
printf "  To test the animated banner right now:\n"
printf "    ${C}bash /etc/profile.d/00-matrix-banner.sh${N}\n"
printf '\n'
printf "  To uninstall:\n"
printf "    ${C}bash uninstall.sh${N}\n"
printf '\n'
